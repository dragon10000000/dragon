// بيانات المستخدم المسجلة مسبقاً
const registeredUser = {
    username: "Moxakis10",
    password: "bahija93"
};

// متغيرات النظام
let currentUser = null;
let aiLevel = 1;
let aiPower = 75;
let aiIntelligence = 60;
let aiExperience = 0;
let isVoiceActive = false;

// عناصر DOM
const loginScreen = document.getElementById("login-screen");
const browserInterface = document.getElementById("browser-interface");
const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");
const loginBtn = document.getElementById("login-btn");
const loginMessage = document.getElementById("login-message");
const logoutBtn = document.getElementById("logout-btn");
const aiLevelElement = document.getElementById("ai-level");
const aiPowerElement = document.getElementById("ai-power");
const aiIntelligenceElement = document.getElementById("ai-intelligence");
const levelProgress = document.getElementById("level-progress");
const powerProgress = document.getElementById("power-progress");
const intelProgress = document.getElementById("intel-progress");
const aiChatMessages = document.getElementById("ai-chat-messages");
const aiUserInput = document.getElementById("ai-user-input");
const aiSendBtn = document.getElementById("ai-send-btn");
const aiVoiceBtn = document.getElementById("ai-voice-btn");
const toolButtons = document.querySelectorAll(".tool-btn");
const contentSections = document.querySelectorAll(".content-section");

// قاعدة معرفة Dragon MX
const aiKnowledgeBase = {
    greetings: [
        "مرحباً بك! Dragon MX في خدمتك.",
        "أهلاً وسهلاً! كيف يمكنني مساعدتك اليوم؟",
        "السلام عليكم، أنا Dragon MX جاهز للعمل."
    ],
    questions: {
        "من أنت": "أنا Dragon MX، ذكاء اصطناعي متطور مصمم لحمايتك ومساعدتك في عالم الإنترنت.",
        "ما هي قدراتك": "أستطيع حمايتك من التهديدات الإلكترونية، مساعدتك في البحث، التعلم من تفاعلاتك، والتطور المستمر.",
        "كيف أطورك": "يمكنك التحدث معي، استخدامي بانتظام، أو شراء ترقيات من متجر التطوير.",
        "ما هو مستواك": `حالياً أنا في المستوى ${aiLevel}، مع قوة ${aiPower}% وذكاء ${aiIntelligence}%.`
    },
    commands: {
        "افتح الأمان": "فتح قسم الأمان...",
        "ابحث عن": (query) => `البحث عن: ${query.replace("ابحث عن", "").trim()}`,
        "تفعيل الصوت": () => {
            toggleVoiceRecognition();
            return "نظام الصوت مفعل الآن. يمكنك التحدث.";
        }
    },
    unknown: [
        "لا أفهم سؤالك بالكامل. هل يمكنك إعادة صياغته؟",
        "هذا السؤال خارج نطاق معرفتي الحالية. ربما بعد التطوير سأتمكن من الإجابة!",
        "لم أتعلم الإجابة على هذا بعد. هل لديك أسئلة أخرى؟"
    ]
};

// تهيئة النظام
document.addEventListener("DOMContentLoaded", () => {
    // تحديث التاريخ والوقت
    updateDateTime();
    setInterval(updateDateTime, 60000);
    
    // نظام التطوير الذاتي
    setInterval(selfImprove, 300000); // كل 5 دقائق
});

// تحديث التاريخ والوقت
function updateDateTime() {
    const now = new Date();
    const timeString = now.toLocaleTimeString("ar-EG", { hour: "numeric", minute: "numeric" });
    const dateString = now.toLocaleDateString("ar-EG", { year: "numeric", month: "numeric", day: "numeric" });
    document.getElementById("time-date").textContent = `${timeString} | ${dateString}`;
}

// نظام التطوير الذاتي
function selfImprove() {
    aiExperience += 5;
    aiIntelligence = Math.min(100, aiIntelligence + 1);
    
    if (aiExperience >= aiLevel * 100) {
        aiLevel++;
        aiExperience = 0;
        aiPower = Math.min(100, aiPower + 10);
        
        // عرض رسالة ترقية
        addAIMessage(`🎉 تهانينا! لقد تطورت إلى المستوى ${aiLevel}! قدراتي تتحسن.`);
    }
    
    updateStats();
}

// تحديث الإحصائيات
function updateStats() {
    aiLevelElement.textContent = aiLevel;
    aiPowerElement.textContent = `${aiPower}%`;
    aiIntelligenceElement.textContent = `${aiIntelligence}%`;
    levelProgress.style.width = `${(aiExperience / (aiLevel * 100)) * 100}%`;
    powerProgress.style.width = `${aiPower}%`;
    intelProgress.style.width = `${aiIntelligence}%`;
    
    // تحديث حالة الذكاء الاصطناعي
    let status = "Dragon MX: ";
    if (aiPower < 30) {
        status += "طاقة منخفضة";
    } else if (aiIntelligence > 80) {
        status += "في أفضل حالاتي";
    } else {
        status += "جاهز";
    }
    document.getElementById("ai-status").textContent = status;
}

// تسجيل الدخول
loginBtn.addEventListener("click", () => {
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();
    
    if (username === registeredUser.username && password === registeredUser.password) {
        // تسجيل الدخول الناجح
        currentUser = username;
        loginScreen.style.display = "none";
        browserInterface.style.display = "flex";
        
        // تحميل بيانات المستخدم
        loadUserData();
        
        // رسالة ترحيبية
        setTimeout(() => {
            addAIMessage(getRandomResponse(aiKnowledgeBase.greetings));
        }, 1000);
    } else {
        // خطأ في تسجيل الدخول
        loginMessage.textContent = "اسم المستخدم أو كلمة المرور غير صحيحة!";
        usernameInput.style.borderColor = "var(--dragon-red)";
        passwordInput.style.borderColor = "var(--dragon-red)";
    }
});

// تسجيل الخروج
logoutBtn.addEventListener("click", () => {
    currentUser = null;
    browserInterface.style.display = "none";
    loginScreen.style.display = "flex";
    loginMessage.textContent = "";
    usernameInput.value = "";
    passwordInput.value = "";
    usernameInput.style.borderColor = "var(--primary-color)";
    passwordInput.style.borderColor = "var(--primary-color)";
});

// تحميل بيانات المستخدم
function loadUserData() {
    // هنا يمكنك إضافة جلب البيانات من localStorage أو API
    console.log(`تم تحميل بيانات ${currentUser}`);
    updateStats();
}

// تبديل أقسام المحتوى
toolButtons.forEach(button => {
    button.addEventListener("click", () => {
        const section = button.getAttribute("data-section");
        
        // إزالة التنشيط من جميع الأزرار
        toolButtons.forEach(btn => btn.classList.remove("active"));
        // تنشيط الزر الحالي
        button.classList.add("active");
        
        // إخفاء جميع الأقسام
        contentSections.forEach(section => section.classList.remove("active"));
        // إظهار القسم المحدد
        document.getElementById(`${section}-section`).classList.add("active");
    });
});

// إرسال رسالة إلى Dragon MX
function sendAIMessage() {
    const message = aiUserInput.value.trim();
    if (!message) return;
    
    addUserMessage(message);
    aiUserInput.value = "";
    
    setTimeout(() => {
        const response = generateAIResponse(message);
        addAIMessage(response);
        
        // زيادة الخبرة
        aiExperience += 5;
        aiIntelligence = Math.min(100, aiIntelligence + 0.5);
        updateStats();
    }, 1000);
}

aiSendBtn.addEventListener("click", sendAIMessage);
aiUserInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") sendAIMessage();
});

// توليد رد من Dragon MX
function generateAIResponse(message) {
    // التحقق من الأوامر
    for (const [cmd, action] of Object.entries(aiKnowledgeBase.commands)) {
        if (message.toLowerCase().startsWith(cmd.toLowerCase())) {
            if (typeof action === "function") {
                return action();
            } else if (typeof action === "string") {
                return action;
            } else {
                return action(message);
            }
        }
    }
    
    // التحقق من الأسئلة المعروفة
    for (const [question, answer] of Object.entries(aiKnowledgeBase.questions)) {
        if (message.toLowerCase().includes(question.toLowerCase())) {
            return answer;
        }
    }
    
    // إذا لم يتعرف على السؤال
    return getRandomResponse(aiKnowledgeBase.unknown);
}

// إضافة رسالة مستخدم
function addUserMessage(text) {
    const messageDiv = document.createElement("div");
    messageDiv.className = "message user-message animate__animated animate__fadeIn";
    messageDiv.innerHTML = `<p>${text}</p>`;
    aiChatMessages.appendChild(messageDiv);
    aiChatMessages.scrollTop = aiChatMessages.scrollHeight;
}

// إضافة رسالة Dragon MX
function addAIMessage(text) {
    const messageDiv = document.createElement("div");
    messageDiv.className = "message ai-message animate // يمكنك إضافة أصوات للحركات
const swordSound = new Audio('sword-swing.mp3');
document.querySelector('.dragon-sword').addEventListener('animationiteration', () => {
    swordSound.currentTime = 0;
    swordSound.play();
}); // تفاعل عند النقر على الشخصية
document.getElementById('dragon-warrior').addEventListener('click', () => {
    const warrior = document.getElementById('dragon-warrior');
    warrior.classList.add('animate__rubberBand');
    setTimeout(() => {
        warrior.classList.remove('animate__rubberBand');
    }, 1000);
    
    // عرض رسالة
    const message = document.createElement('div');
    message.textContent = "Dragon MX جاهز للقتال!";
    message.style.position = 'absolute';
    message.style.color = 'var(--dragon-red)';
    message.style.fontWeight = 'bold';
    message.style.animation = 'float-up 2s forwards';
    document.getElementById('browser-content').appendChild(message);
    setTimeout(() => message.remove(), 2000);
});// عند النقر على زر القوة
document.querySelector('.footer-btn:nth-child(1)').addEventListener('click', () => {
    const warrior = document.getElementById('dragon-warrior');
    warrior.style.animation = 'combat-mode 0.5s forwards';
    
    // تغيير لون الخوذة
    document.querySelector('.dragon-visor').style.background = 
        'linear-gradient(90deg, #ff0000, #ff6600)';
    
    // تأثيرات إضافية
    createExplosionEffect();
});// تخزين مشفر لكلمة السر (مثال بسيط)
function encryptPassword(pass) {
    return btoa(pass + "dragon_salt");
}

// التحقق المعزز
function enhancedLoginCheck(user, pass) {
    const storedPass = localStorage.getItem('encryptedPass');
    return user === "Moxakis10" && encryptPassword(pass) === storedPass;
}usernameInput.classList.add('animate__shakeX');
setTimeout(() => {
    usernameInput.classList.remove('animate__shakeX');
}, 1000);setTimeout(() => {
    loginMessage.textContent = "";
}, 3000);let aiLevel = 1;
let aiXP = 0;

function gainXP(amount) {
    aiXP += amount;
    if (aiXP >= aiLevel * 100) {
        aiLevel++;
        aiXP = 0;
        showLevelUpMessage();
    }
}

function showLevelUpMessage() {
    // عرض رسالة تطور
}const dragonResponses = {
    greet: ["أهلاً بك في عالم Dragon MX!", "جاهز للعمل يا محارب!", "أنتارا.إكس في خدمتك!"],
    combat: ["تهديد محتمل تم اكتشافه!", "جاري تنشيط أنظمة الدفاع!", "جاهز للقتال!"],
    error: ["لا أفهم الأمر بالكامل", "بحاجة إلى مزيد من البيانات", "جرب صيغة أخرى"]
};

function getRandomResponse(type) {
    return dragonResponses[type][Math.floor(Math.random() * dragonResponses[type].length)];
}function scanForThreats() {
    setInterval(() => {
        // فحص التهديدات كل 5 دقائق
        console.log("جاري فحص النظام...");
    }, 300000);
}// في ملف script.js
async function searchWeb(query) {
    try {
        // البحث عن معلومات عامة
        const ddgResponse = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1`);
        const ddgData = await ddgResponse.json();
        
        // البحث عن حلول رياضية
        const mathResponse = await fetch(`https://api.wolframalpha.com/v1/result?i=${encodeURIComponent(query)}&appid=YOUR_WOLFRAM_APPID`);
        const mathData = await mathResponse.text();
        
        return {
            abstract: ddgData.AbstractText || "لا توجد معلومات متاحة",
            mathSolution: mathData.includes("=") ? mathData : "لا يمكن حل هذه المسألة",
            relatedTopics: ddgData.RelatedTopics?.map(topic => topic.Text) || []
        };
    } catch (error) {
        console.error("خطأ في البحث:", error);
        return {
            abstract: "حدث خطأ أثناء البحث",
            mathSolution: "",
            relatedTopics: []
        };
    }
}

// دالة معالجة الأسئلة
async function handleQuery(query) {
    if (isMathQuestion(query)) {
        const result = await searchWeb(query);
        return `🎯 الحل الرياضي: ${result.mathSolution || "غير متوفر"}`;
    }
    else if (isPersonQuery(query)) {
        const result = await searchWeb(query);
        return `🧑‍🎤 معلومات عن ${query}: ${result.abstract || "غير متوفر"}`;
    }
    else {
        const result = await searchWeb(query);
        return `🔍 نتائج البحث: ${result.abstract || "لا توجد معلومات"}${result.relatedTopics.length ? "\n\nمواضيع ذات صلة:\n" + result.relatedTopics.join("\n") : ""}`;
    }
}

function isMathQuestion(query) {
    return /[\d+\-*/^=]|معدل|حساب|رياضيات|مسألة/.test(query);
}

function isPersonQuery(query) {
    return /شخصية|مشهور|ممثل|مغني|كاتب|عالم/.test(query);
}async function generateImage(prompt) {
    try {
        const response = await fetch("https://api.stablediffusionapi.com/v1/generate", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer YOUR_API_KEY"
            },
            body: JSON.stringify({
                prompt: prompt,
                width: 512,
                height: 512,
                samples: 1
            })
        });
        
        const data = await response.json();
        return data.output?.[0] || "https://via.placeholder.com/512?text=Error+Generating+Image";
    } catch (error) {
        console.error("خطأ في توليد الصورة:", error);
        return "https://via.placeholder.com/512?text=Error+Generating+Image";
    }
}// في ملف script.js
document.getElementById("ai-send-btn").addEventListener("click", async () => {
    const userInput = document.getElementById("ai-user-input").value.trim();
    if (!userInput) return;
    
    addMessage(userInput, "user");
    document.getElementById("ai-user-input").value = "";
    
    // عرض مؤشر تحميل
    const loadingMsg = addMessage("🔎 جاري البحث...", "bot");
    
    try {
        let response;
        
        if (userInput.startsWith("ارسم")) {
            const prompt = userInput.replace("ارسم", "").trim();
            response = "🖼️ جاري توليد الصورة...";
            loadingMsg.querySelector("p").textContent = response;
            
            const imageUrl = await generateImage(prompt);
            addImageMessage(imageUrl, prompt);
        } 
        else {
            response = await handleQuery(userInput);
            loadingMsg.querySelector("p").textContent = response;
        }
        
        // زيادة الخبرة
        gainXP(15);
        
    } catch (error) {
        loadingMsg.querySelector("p").textContent = "⚠️ حدث خطأ أثناء معالجة طلبك";
        console.error(error);
    }
});

function addImageMessage(imageUrl, prompt) {
    const messageDiv = document.createElement("div");
    messageDiv.className = "message bot-message";
    messageDiv.innerHTML = `
        <p>الصورة المولدة لـ "${prompt}"</p>
        <img src="${imageUrl}" alt="${prompt}" class="generated-image">
        <div class="image-actions">
            <button class="save-img-btn">💾 حفظ</button>
            <button class="regenerate-img-btn">🔄 إعادة توليد</button>
        </div>
    `;
    document.getElementById